<?php



// Non du dossier, nom du fichier, nom de la classe doit être exactement le même

class tp_Avis_Produits extends Module
{

    public function __construct()
    {

        $this->displayName = "Avis produits"; // nom publique visible par le marchand
        $this->name = "tp_avis_produits";
        $this->version = "1.0";
        $this->author = "Lucien Bruzzese";
        $this->description = "Création d'avis de produits";
        $this->bootstrap = true;

        parent::__construct();
    }

    public function install()
    {

        //methode registerHook permet de greffer mon module sur un hook de presta

        if (
            !parent::install()
            || !$this->registerHook('displayFooterProduct')
            || !$this->CreateTable()
        ) {

            return false;
        }

        return true;
    }

    public function hookdisplayFooterProduct()
    {
    }

    private function CreateTable()
    {

        //_DB_PREFIX constante qui contient le prefix de la tables (ps_)

        //clé primaire : toujours égale à id_.nom_table

        $sql = 'CREATE TABLE IF NOT EXISTS ' . _DB_PREFIX_ . 'avis_produit (
			id_avis_produit int(11) NOT NULL AUTO_INCREMENT,
			id_product INT(11) NOT NULL,
			id_customer INT(11),
			note tinyint(1) NULL,
			avis text NOT NULL,
			date_add datetime NOT NULL,
			PRIMARY KEY (id_avis_produit)
		) ENGINE=' . _MYSQL_ENGINE_ . 'DEFAULT CHARSET=utf8;';

        //class dB me permet de créer des requete SQL
        //getInstance() contient la connexion à la bdd
        //execute permet d'executer des requetes de type insert/update/delete/create mais pas SELECT

        if (Db::getInstance()->execute($sql) == false)
            return false;

        return true;
    }

    //ajoute le bouton configurer
    public function getContent()
    {



        return $this->displayForm();
    }

    // génère le formulaire de configuration via helperform
    public function displayForm()
    {

        if (Configuration::get('IMAGE')) {
            $lienimage = _MODULE_DIR_ . $this->name . '/views/assets/img/' . Configuration::get('LB_IMAGE_1');
        }

        $form_configuration['0']['form'] = [
            'legend' => [
                'title' => $this->l('Configuration')
            ],
            'input' => [
                [
                    'type' => 'switch',
                    'label' => 'Obligation d\'être connecté pour commenter',
                    'name' => 'OBLIGATION_CONNEXION',
                    'is_bool' => true,
                    'values' => array(
                        array(
                            'id' => 'active_on',
                            'value' => 1,
                            'label' => $this->l('Oui')
                        ),
                        array(
                            'id' => 'active_off',
                            'value' => 0,
                            'label' => $this->l('Non')
                        ),
                    )
                ],
                [
                    'type' => 'switch',
                    'label' => 'Pouvoir noter le produit',
                    'name' => 'NOTE_PRODUIT',
                    'is_bool' => true,
                    'values' => array(
                        array(
                            'id' => 'active_on',
                            'value' => 1,
                            'label' => $this->l('Oui')
                        ),
                        array(
                            'id' => 'active_off',
                            'value' => 0,
                            'label' => $this->l('Non')
                        ),
                    )
                ],

                [
                    'type' => 'textarea',
                    'label' => $this->l('Commentaire'),
                    'name' => 'COMMENTAIRE',
                    'required' => true,
                    'autoload_rte' => true,
                ],
                [
                    'type' => 'file',
                    'label' => 'Image',
                    'name' => 'IMAGE',
                    'required' => true,
                    'image' => (isset($lienimage) && $lienimage ? '<img src="' . $lienimage . '" width="200px" height="auto">' : false)
                ],


            ],

            'submit' => [
                'title' => $this->l('Save'),
                'class' => 'btn btn-defult pull-right'
            ]
        ];

        $helper = new HelperForm();

        $helper->module = $this; // instance du module
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules'); //récupère le token de la page module

        $helper->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name; //configurer l'atttribut action du formulaire
        $helper->default_form_language = (int)configuration::get('PS_LANG_DEFAULT');
        $helper->title = $this->displayName;
        $helper->submit_action = "submit_" . $this->name;  //ajoute un attribut name a mon bouton

        $helper->fields_value['OBLIGATION_CONNEXION'] = Tools::getValue('OBLIGATION_CONNEXION', Configuration::get('OBLIGATION_CONNEXION'));
        $helper->fields_value['NOTE_PRODUIT'] = Tools::getValue('NOTE_PRODUIT', Configuration::get('NOTE_PRODUIT'));
        $helper->fields_value['COMMENTAIRE'] = Tools::getValue('COMMENTAIRE', Configuration::get('COMMENTAIRE'));
        $helper->fields_value['IMAGE'] = Tools::getValue('IMAGE', Configuration::get('IMAGE'));

        return $helper->generateForm($form_configuration);
    }
}
